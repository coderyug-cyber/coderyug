<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="LoginAction.php" method="post">
        <label for="username">User Name:</label>
        <input type="text" id="username" name="username">   
        <br><br>
        <label for="password">Password:</label> 
        <input type="password" id="password" name="password"><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>